# Firestore Security Specification

This document defines the strict data invariants, malicious payload vectors ("Dirty Dozen"), and the security test parameters for our zero-trust Firestore setup.

## 1. Data Invariants

1. **Strict User isolation**: No user can read, list, update, create, or delete any configurations, logging collections, or states that belong to another user.
2. **Identity Integrity**: All documents stored under `/users/{userId}` must have fields matching the authenticated user's ID (`request.auth.uid`).
3. **Temporal Validity**: Any creation or write update must synchronize the update time with the Firebase server-generated timestamp (`request.time`).
4. **Key Whitelisting**: Updates are strictly constrained through named update actions using `affectedKeys().hasOnly()` gates.

---

## 2. The "Dirty Dozen" Vulnerability Vector Scenarios

Below are 12 JSON requests representing hostile clients attempting to bypass validation logic.

### Scenario A: Identity Spoofing & Cross-Tenant Read/Write
1. **Payload 1 (Malicious Write to Sibling Node)**: Sibling user `attacker_id` tries to write an integration configuration directly into `/users/target_user_id/config/integrations`.
2. **Payload 2 (Anonymous Sneaking)**: Unauthenticated visitor attempts to read `/users/target_user_id/data/appState`.
3. **Payload 3 (Spoofing Owner Matching)**: User `u-1234` tries to write `{ userId: "u-9999" }` inside `/users/u-1234/data/appState`.

### Scenario B: Shadow Updates & Schema Overwrite (Update Gaps)
4. **Payload 4 (Ghost Attribute Injection)**: A valid user injects `{ isAdmin: true, superuser: true }` when saving their configuration inside `/users/u-1234/config/integrations`.
5. **Payload 5 (Value Poisoning - Payload Overflow)**: A user submits an extremely large block of random string text in `dailyBlockers` (e.g. 5MB) attempting to trigger billing resource exhaustion.
6. **Payload 6 (No-timestamp bypass)**: A client attempts to push a document update with user-side overrides without supplying `{ updatedAt: request.time }`.

### Scenario C: Uncontrolled Multi-User Queries (Secure Collection Scraping)
7. **Payload 7 (Unfiltered List Extraction)**: A client issues a blanket list collection query on `/users` across all profiles without applying a valid `where("userId", "==", auth.uid)` filter.

### Scenario D: System State Short-circuiting & Type Mismatch
8. **Payload 8 (State Spoofing)**: Submitting local configs with `integrations` mapped as a basic string instead of an object type map.
9. **Payload 9 (Task list type corruption)**: Injecting `{ actionTaskItems: "this is string" }` into the user's saved application state collection.
10. **Payload 10 (Decision signee invalid identifier)**: Writing `{ decisionsHistory: [{ id: "###", decision: "Invalid ID with special characters", author: "@#$%^&" }] }` to compromise identifier safety rules.

### Scenario E: IMMOBILITY Bypasses
11. **Payload 11 (Overwriting CreatedAt)**: Replacing the immutable `createdAt` timestamp value with an older date.
12. **Payload 12 (Changing document path variables)**: Attempting to call updates with an invalid character string as a document ID.

---

## 3. Test Runner Design

```typescript
// firestore.rules.test.ts
import { assertFails, assertSucceeds, initializeTestEnvironment } from "@firebase/rules-unit-testing";

describe("MeetFlow Zero-Trust Security Audits", () => {
  let testEnv: any;

  beforeAll(async () => {
    testEnv = await initializeTestEnvironment({
      projectId: "ai-team-brain-1244f",
    });
  });

  afterAll(async () => {
    await testEnv.cleanup();
  });

  test("Pillar 1: Prevent unauthorized cross-tenant writes", async () => {
    const maliciousAlice = testEnv.authenticatedContext("alice_id");
    const db = maliciousAlice.firestore();
    const docRef = db.doc("users/bob_id/config/integrations");
    await assertFails(docRef.set({
      userId: "bob_id",
      integrations: {},
      updatedAt: new Date()
    }));
  });

  test("Pillar 2: Reject updates containing ghost fields", async () => {
    const userContext = testEnv.authenticatedContext("user_123");
    const db = userContext.firestore();
    const docRef = db.doc("users/user_123/config/integrations");
    await assertFails(docRef.update({
      ghostField: "unauthorized"
    }));
  });
});
```
